/* ==========================================================================
   BBA PREMIUM PACKAGING WEBSITE - INTERACTION LOGIC (VANILLA JS)
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  
  // ==========================================
  // 1. MOBILE MENU TOGGLE
  // ==========================================
  const menuToggle = document.getElementById('menu-toggle');
  const mainNav = document.getElementById('main-nav');
  
  if (menuToggle && mainNav) {
    menuToggle.addEventListener('click', () => {
      menuToggle.classList.toggle('active');
      mainNav.classList.toggle('active');
    });

    // Close nav on click of links
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
      link.addEventListener('click', () => {
        menuToggle.classList.remove('active');
        mainNav.classList.remove('active');
      });
    });
  }

  // ==========================================
  // 2. CANVAS CUSTOM PARTICLE SYSTEM (Hero Background)
  // ==========================================
  const canvas = document.getElementById('particles-canvas');
  if (canvas) {
    const ctx = canvas.getContext('2d');
    let particlesArray = [];
    let mouse = { x: null, y: null, radius: 150 };

    // Track mouse move for deflection
    window.addEventListener('mousemove', (e) => {
      mouse.x = e.x;
      mouse.y = e.y;
    });
    
    window.addEventListener('mouseout', () => {
      mouse.x = null;
      mouse.y = null;
    });

    // Resize handler
    function resizeCanvas() {
      const parent = canvas.parentElement;
      canvas.width = parent.clientWidth;
      canvas.height = parent.clientHeight;
      initParticles();
    }
    window.addEventListener('resize', resizeCanvas);

    class Particle {
      constructor(width, height) {
        this.x = Math.random() * width;
        this.y = Math.random() * height;
        this.size = Math.random() * 2 + 1; // 1px to 3px
        this.speedX = (Math.random() - 0.5) * 0.3;
        this.speedY = -Math.random() * 0.4 - 0.1; // Slow floating upwards
        
        // Navy-blue & Glowing red floating colors
        const colors = [
          'rgba(255, 42, 84, 0.4)', // Glowing red
          'rgba(255, 42, 84, 0.25)', 
          'rgba(17, 29, 53, 0.5)',   // Navy-blue
          'rgba(148, 163, 184, 0.3)'  // Slate silver
        ];
        this.color = colors[Math.floor(Math.random() * colors.length)];
      }

      update(width, height) {
        this.x += this.speedX;
        this.y += this.speedY;

        // Reset if floats off screen
        if (this.y < 0) {
          this.y = height;
          this.x = Math.random() * width;
        }
        if (this.x < 0 || this.x > width) {
          this.x = Math.random() * width;
        }

        // Mouse deflection effect
        if (mouse.x !== null && mouse.y !== null) {
          let dx = this.x - mouse.x;
          let dy = this.y - mouse.y;
          let distance = Math.sqrt(dx * dx + dy * dy);
          if (distance < mouse.radius) {
            let forceDirectionX = dx / distance;
            let forceDirectionY = dy / distance;
            let force = (mouse.radius - distance) / mouse.radius;
            let directionX = forceDirectionX * force * 1.5;
            let directionY = forceDirectionY * force * 1.5;
            this.x += directionX;
            this.y += directionY;
          }
        }
      }

      draw() {
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fillStyle = this.color;
        ctx.fill();
      }
    }

    function initParticles() {
      particlesArray = [];
      const numberOfParticles = Math.floor((canvas.width * canvas.height) / 12000);
      for (let i = 0; i < numberOfParticles; i++) {
        particlesArray.push(new Particle(canvas.width, canvas.height));
      }
    }

    function animateParticles() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      for (let i = 0; i < particlesArray.length; i++) {
        particlesArray[i].update(canvas.width, canvas.height);
        particlesArray[i].draw();
      }
      requestAnimationFrame(animateParticles);
    }

    // Initialize
    const parent = canvas.parentElement;
    canvas.width = parent.clientWidth;
    canvas.height = parent.clientHeight;
    initParticles();
    animateParticles();
  }

  // ==========================================
  // 3. CUSTOM MAGNETIC CURSOR
  // ==========================================
  const cursor = document.getElementById('custom-cursor');
  const cursorDot = document.getElementById('custom-cursor-dot');
  
  let mouseX = 0, mouseY = 0;
  let cursorX = 0, cursorY = 0;
  let dotX = 0, dotY = 0;
  let isMoving = false;

  window.addEventListener('mousemove', (e) => {
    mouseX = e.clientX;
    mouseY = e.clientY;
    
    // Add activation class on first mouse movement
    if (!isMoving) {
      document.body.classList.add('has-custom-cursor');
      isMoving = true;
    }
  });

  // Smooth cursor follow simulation (Lerp)
  function updateCursor() {
    // Lerp coordinates
    cursorX += (mouseX - cursorX) * 0.15;
    cursorY += (mouseY - cursorY) * 0.15;
    
    dotX += (mouseX - dotX) * 0.4;
    dotY += (mouseY - dotY) * 0.4;

    if (cursor) {
      cursor.style.left = `${cursorX}px`;
      cursor.style.top = `${cursorY}px`;
    }
    if (cursorDot) {
      cursorDot.style.left = `${dotX}px`;
      cursorDot.style.top = `${dotY}px`;
    }
    requestAnimationFrame(updateCursor);
  }
  updateCursor();

  // Add Hover Class to custom cursor on interactive links
  const interactives = document.querySelectorAll('a, button, select, input, textarea, label, [role="button"]');
  interactives.forEach(el => {
    el.addEventListener('mouseenter', () => {
      if (cursor) cursor.classList.add('cursor-hover');
    });
    el.addEventListener('mouseleave', () => {
      if (cursor) cursor.classList.remove('cursor-hover');
    });
  });

  // Magnetic Button Effect on CTA/Hover Elements
  const magneticItems = document.querySelectorAll('.btn, .header-cta, .social-btn, .product-cta');
  magneticItems.forEach(item => {
    item.addEventListener('mousemove', (e) => {
      const rect = item.getBoundingClientRect();
      const relX = e.clientX - rect.left;
      const relY = e.clientY - rect.top;
      
      // Compute displacement from center
      const xForce = (relX - rect.width / 2) * 0.25;
      const yForce = (relY - rect.height / 2) * 0.25;
      
      item.style.transform = `translate(${xForce}px, ${yForce}px)`;
      
      // Pull custom cursor ring slightly toward center of button
      if (cursor) {
        cursorX += (rect.left + rect.width / 2 - cursorX) * 0.1;
        cursorY += (rect.top + rect.height / 2 - cursorY) * 0.1;
      }
    });

    item.addEventListener('mouseleave', () => {
      item.style.transform = 'translate(0px, 0px)';
    });
  });

  // ==========================================
  // 4. INTERSECTION OBSERVER REVEAL ANIMATIONS
  // ==========================================
  const revealElements = document.querySelectorAll('.reveal, .reveal-left, .reveal-right');
  
  const revealObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const delay = el.getAttribute('data-delay') || 0;
        
        setTimeout(() => {
          el.classList.add('reveal-visible');
        }, delay);
        
        observer.unobserve(el); // Animate only once
      }
    });
  }, {
    threshold: 0.15,
    rootMargin: '0px 0px -50px 0px'
  });

  revealElements.forEach(el => {
    revealObserver.observe(el);
  });

  // ==========================================
  // 5. IN-VIEWPORT ANIMATED COUNTERS
  // ==========================================
  const counters = document.querySelectorAll('.trust-number[data-target]');
  
  const counterObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const counter = entry.target;
        const target = parseInt(counter.getAttribute('data-target'));
        const duration = 1800; // 1.8 seconds
        const startTime = performance.now();
        
        function updateCount(currentTime) {
          const elapsed = currentTime - startTime;
          const progress = Math.min(elapsed / duration, 1);
          
          // Cubic ease-out
          const easeProgress = 1 - Math.pow(1 - progress, 3);
          const currentCount = Math.floor(easeProgress * target);
          
          if (target === 100) {
            counter.innerText = `${currentCount}%`;
          } else {
            counter.innerText = `${currentCount}+`;
          }
          
          if (progress < 1) {
            requestAnimationFrame(updateCount);
          } else {
            if (target === 100) {
              counter.innerText = `100%`;
            } else {
              counter.innerText = `${target}+`;
            }
          }
        }
        
        requestAnimationFrame(updateCount);
        observer.unobserve(counter);
      }
    });
  }, {
    threshold: 0.5
  });

  counters.forEach(counter => {
    counterObserver.observe(counter);
  });

  // ==========================================
  // 6. 3D CARD TILT EFFECT (Product Cards)
  // ==========================================
  const productCards = document.querySelectorAll('.product-card');
  
  productCards.forEach(card => {
    card.addEventListener('mousemove', (e) => {
      if (window.innerWidth <= 992) return; // Skip on mobile
      
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left; // Mouse relative X
      const y = e.clientY - rect.top;  // Mouse relative Y
      
      // Distance from center (-0.5 to 0.5 range)
      const xc = rect.width / 2;
      const yc = rect.height / 2;
      const dx = (x - xc) / xc; 
      const dy = (y - yc) / yc;
      
      // Calculate rotation angles (max 10 degrees)
      const rotateX = -dy * 10;
      const rotateY = dx * 10;
      
      card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`;
    });
    
    card.addEventListener('mouseleave', () => {
      card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)';
    });
  });

  // ==========================================
  // 7. DESKTOP VERTICAL-TO-HORIZONTAL SCROLL (Products)
  // ==========================================
  const productsContainer = document.getElementById('products-container');
  
  if (productsContainer) {
    productsContainer.addEventListener('wheel', (e) => {
      if (window.innerWidth > 992) {
        const isAtStart = productsContainer.scrollLeft === 0;
        const isAtEnd = Math.ceil(productsContainer.scrollLeft + productsContainer.clientWidth) >= productsContainer.scrollWidth;
        
        // Scroll horizontally if we haven't hit boundaries
        if (e.deltaY > 0 && !isAtEnd) {
          e.preventDefault();
          productsContainer.scrollLeft += e.deltaY;
        } else if (e.deltaY < 0 && !isAtStart) {
          e.preventDefault();
          productsContainer.scrollLeft += e.deltaY;
        }
      }
    }, { passive: false });
  }

  // ==========================================
  // 8. PARALLAX SCROLLING EFFECT
  // ==========================================
  const heroBg = document.getElementById('hero-bg');
  const aboutBg = document.getElementById('about-bg');
  const tourBg = document.getElementById('tour-bg');
  
  let lastScrollY = window.scrollY;
  let ticking = false;

  window.addEventListener('scroll', () => {
    lastScrollY = window.scrollY;
    if (!ticking) {
      window.requestAnimationFrame(() => {
        applyParallax();
        applyStickyHeaderAndCta();
        ticking = false;
      });
      ticking = true;
    }
  });

  function applyParallax() {
    const windowHeight = window.innerHeight;
    
    // 1. Hero Background Parallax
    if (heroBg) {
      heroBg.style.transform = `translate3d(0, ${lastScrollY * 0.2}px, 0)`;
    }

    // 2. About Background Parallax
    if (aboutBg) {
      const parent = aboutBg.parentElement;
      const rect = parent.getBoundingClientRect();
      const inView = (rect.top < windowHeight) && (rect.bottom > 0);
      if (inView) {
        // Compute movement percentage relative to scroll
        const offset = (windowHeight - rect.top) * 0.1;
        aboutBg.style.transform = `translate3d(0, ${offset - 100}px, 0)`;
      }
    }

    // 3. Tour Background Parallax
    if (tourBg) {
      const parent = tourBg.parentElement;
      const rect = parent.getBoundingClientRect();
      const inView = (rect.top < windowHeight) && (rect.bottom > 0);
      if (inView) {
        const offset = (windowHeight - rect.top) * 0.12;
        tourBg.style.transform = `translate3d(0, ${offset - 120}px, 0)`;
      }
    }
  }

  // ==========================================
  // 9. STICKY HEADER & FLOATING CTA
  // ==========================================
  const header = document.getElementById('header');
  const stickyCta = document.getElementById('sticky-cta');

  function applyStickyHeaderAndCta() {
    // Header scrolled class
    if (lastScrollY > 60) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }

    // Sticky CTA visibility after hero section
    if (lastScrollY > window.innerHeight - 150) {
      stickyCta.classList.add('visible');
    } else {
      stickyCta.classList.remove('visible');
    }
  }
  
  // Call once initially to set initial states
  applyStickyHeaderAndCta();

  // ==========================================
  // 10. REVIEWS AUTO-ROTATING CAROUSEL (Fade)
  // ==========================================
  const cards = document.querySelectorAll('.review-card');
  const dots = document.querySelectorAll('.carousel-dot');
  let currentReviewIndex = 0;
  let carouselInterval;

  function showReview(index) {
    cards.forEach(card => card.classList.remove('active'));
    dots.forEach(dot => dot.classList.remove('active'));
    
    cards[index].classList.add('active');
    dots[index].classList.add('active');
    currentReviewIndex = index;
  }

  function startCarouselTimer() {
    clearInterval(carouselInterval);
    carouselInterval = setInterval(() => {
      let nextIndex = (currentReviewIndex + 1) % cards.length;
      showReview(nextIndex);
    }, 5000); // Rotate every 5 seconds
  }

  dots.forEach(dot => {
    dot.addEventListener('click', () => {
      const slideIndex = parseInt(dot.getAttribute('data-slide'));
      showReview(slideIndex);
      startCarouselTimer(); // Reset timer on click
    });
  });

  if (cards.length > 0) {
    startCarouselTimer();
  }

  // ==========================================
  // 11. SOCIAL PROOF COUNTRY TICKER DECORATION
  // ==========================================
  // Duplicate ticker items to make the animation continuous and seamless
  const tickerContent = document.getElementById('ticker-content');
  if (tickerContent) {
    const duplicates = tickerContent.innerHTML;
    // Add two copies to guarantee overlap is filled
    tickerContent.innerHTML = duplicates + duplicates + duplicates;
  }

  // ==========================================
  // 12. SMART INQUIRY FORM VALIDATION
  // ==========================================
  const form = document.getElementById('inquiry-form');
  const submitBtn = document.getElementById('submit-btn');

  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      
      const name = document.getElementById('full-name').value.trim();
      const company = document.getElementById('company-name').value.trim();
      const country = document.getElementById('country').value;
      const quantity = document.getElementById('quantity').value;
      const message = document.getElementById('message').value.trim();

      // Reset button state
      submitBtn.innerText = "Processing...";
      submitBtn.disabled = true;

      // Basic field checking
      if (!name || !company || !country || !quantity) {
        showFeedback("Please fill in all mandatory fields (*) marked on the form.", "error");
        submitBtn.innerText = "Send Inquiry";
        submitBtn.disabled = false;
        return;
      }

      // Simulate API submission
      setTimeout(() => {
        // Success feedback
        showFeedback(`Thank you, ${name}! Your inquiry has been sent securely. Our Ganzhou export office will respond to ${company} within 24 hours.`, "success");
        form.reset();
        submitBtn.innerText = "Send Inquiry";
        submitBtn.disabled = false;
      }, 1500);
    });
  }

  function showFeedback(text, type) {
    // Create feedback banner
    const banner = document.createElement('div');
    banner.style.position = 'fixed';
    banner.style.top = '2rem';
    banner.style.right = '2rem';
    banner.style.padding = '1.25rem 2rem';
    banner.style.borderRadius = '8px';
    banner.style.zIndex = '99999';
    banner.style.color = '#ffffff';
    banner.style.fontWeight = '600';
    banner.style.boxShadow = '0 10px 25px rgba(0,0,0,0.3)';
    banner.style.maxWidth = '400px';
    banner.style.lineHeight = '1.4';
    banner.style.fontSize = '0.95rem';
    banner.style.transition = 'opacity 0.4s, transform 0.4s';
    banner.style.transform = 'translateY(-20px)';
    banner.style.opacity = '0';

    if (type === "success") {
      banner.style.backgroundColor = '#10B981'; // Green
      banner.style.borderLeft = '6px solid #047857';
    } else {
      banner.style.backgroundColor = '#EF4444'; // Red
      banner.style.borderLeft = '6px solid #B91C1C';
    }

    banner.innerText = text;
    document.body.appendChild(banner);

    // Fade in
    setTimeout(() => {
      banner.style.transform = 'translateY(0)';
      banner.style.opacity = '1';
    }, 50);

    // Fade out and remove
    setTimeout(() => {
      banner.style.transform = 'translateY(-20px)';
      banner.style.opacity = '0';
      setTimeout(() => {
        document.body.removeChild(banner);
      }, 400);
    }, 4500);
  }
});
